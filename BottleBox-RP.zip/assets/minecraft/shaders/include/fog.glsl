#version 150

// BottleBox halloween: purple fog that starts closer. Short fogs (water, lava, powder snow, blindness)
// keep their vanilla look.
vec3 bb_spooky(vec3 c) {
    float lum = dot(c, vec3(0.299, 0.587, 0.114));
    vec3 night = vec3(0.13, 0.07, 0.21);
    vec3 day = vec3(0.56, 0.47, 0.68);
    return mix(c, mix(night, day, smoothstep(0.04, 0.65, lum)), 0.68);
}

vec4 linear_fog(vec4 inColor, float vertexDistance, float fogStart, float fogEnd, vec4 fogColor) {
    bool world = fogEnd > 24.0 && fogEnd < 100000.0;
    float start = world ? min(fogStart, fogEnd * 0.22) : fogStart;
    if (vertexDistance <= start) {
        return inColor;
    }

    float fogValue = vertexDistance < fogEnd ? smoothstep(start, fogEnd, vertexDistance) : 1.0;
    vec3 color = world ? bb_spooky(fogColor.rgb) : fogColor.rgb;
    return vec4(mix(inColor.rgb, color, fogValue * fogColor.a), inColor.a);
}

float linear_fog_fade(float vertexDistance, float fogStart, float fogEnd) {
    if (vertexDistance <= fogStart) {
        return 1.0;
    } else if (vertexDistance >= fogEnd) {
        return 0.0;
    }

    return smoothstep(fogEnd, fogStart, vertexDistance);
}

float fog_distance(vec3 pos, int shape) {
    if (shape == 0) {
        return length(pos);
    } else {
        float distXZ = length(pos.xz);
        float distY = abs(pos.y);
        return max(distXZ, distY);
    }
}
