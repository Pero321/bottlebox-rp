#version 150

// BottleBox: GUI fills, with what the fragment shader needs to recolour the tab list's backing.

in vec3 Position;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec4 vertexColor;
out vec2 guiPos;
out vec2 corner;
out float guiWidth;
flat out int kind;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexColor = Color;
    guiPos = Position.xy;
    // fills are quads: every 4 vertices are one rectangle's corners
    int c = gl_VertexID % 4;
    corner = vec2(c >= 2 ? 1.0 : 0.0, (c == 1 || c == 2) ? 1.0 : 0.0);
    guiWidth = 2.0 / ProjMat[0][0];
    kind = 0;
    if (Color.r < 0.002 && Color.g < 0.002 && Color.b < 0.002 && abs(Color.a - 128.0 / 255.0) < 0.002) {
        kind = 1;                       // 0x80000000: the tab backing (and a few other dark panels)
    } else if (Color.r > 0.998 && Color.g > 0.998 && Color.b > 0.998 && abs(Color.a - 32.0 / 255.0) < 0.002) {
        kind = 2;                       // 0x20FFFFFF: a player row in the tab
    }
}
