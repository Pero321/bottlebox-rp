#version 150

#moj_import <minecraft:fog.glsl>

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;

out vec4 fragColor;

void main() {
    // BottleBox halloween: the sky dome gets the purple cast of the fog
    vec4 sky = vec4(bb_spooky(ColorModulator.rgb), ColorModulator.a);
    fragColor = linear_fog(sky, vertexDistance, FogStart, FogEnd, FogColor);
}
