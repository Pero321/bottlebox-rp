#version 150

// BottleBox Halloween tab: one violet -> burnt orange gradient over the three backing blocks (header, players,
// footer) and one pumpkin-orange frame round the outside. Each block is recognised by where it is.

in vec4 vertexColor;
in vec2 guiPos;
in vec2 corner;
in float guiWidth;
flat in int kind;

uniform vec4 ColorModulator;

out vec4 fragColor;

const vec3 TOP = vec3(42.0, 14.0, 61.0) / 255.0;
const vec3 BOTTOM = vec3(90.0, 34.0, 8.0) / 255.0;
const vec4 RIM = vec4(1.0, 138.0 / 255.0, 30.0 / 255.0, 0.75);

void main() {
    vec4 color = vertexColor;
    if (kind == 1) {
        // the rectangle this fragment belongs to, from how position and corner change across the screen
        mat2 dpos = mat2(dFdx(guiPos), dFdy(guiPos));
        mat2 duv = mat2(dFdx(corner), dFdy(corner));
        if (abs(determinant(duv)) > 1e-9) {
            mat2 D = dpos * inverse(duv);
            vec2 o = guiPos - D * corner;
            vec2 p1 = o + D[0];
            vec2 p2 = o + D[1];
            vec2 p3 = o + D[0] + D[1];
            vec2 mn = min(min(o, p1), min(p2, p3));
            vec2 mx = max(max(o, p1), max(p2, p3));
            float h = mx.y - mn.y;
            bool centred = abs(mn.x + mx.x - guiWidth) <= 2.5;
            int part = -1;
            if (centred && abs(mn.y - 9.0) < 0.5 && abs(h - 19.0) < 0.5) part = 0;        // header, 2 lines
            else if (centred && abs(mn.y - 28.0) < 0.5) part = 1;                          // players
            else if (centred && mn.y > 28.5 && abs(h - 19.0) < 0.5) part = 2;             // footer, 2 lines
            if (part >= 0) {
                float f = clamp((guiPos.y - mn.y) / max(h, 1.0), 0.0, 1.0);
                float k = part == 0 ? f * 0.12 : (part == 1 ? 0.12 + f * 0.76 : 0.88 + f * 0.12);
                color = vec4(mix(TOP, BOTTOM, k), 0.55);
                bool rim = guiPos.x - mn.x < 1.0 || mx.x - guiPos.x < 1.0
                        || (part == 0 && guiPos.y - mn.y < 1.0) || (part == 2 && mx.y - guiPos.y < 1.0);
                if (rim) color = RIM;
            }
        }
    } else if (kind == 2) {
        color = vec4(1.0, 0.63, 0.27, 0.14);
    }
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
