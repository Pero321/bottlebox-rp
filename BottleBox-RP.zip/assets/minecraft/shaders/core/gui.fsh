#version 150

// BottleBox New Year tab: one night blue -> wine red gradient over the three backing blocks (header, players,
// footer) and one gold frame round the outside. Each block is recognised by where it is.

in vec4 vertexColor;
in vec2 guiPos;
in vec2 corner;
in float guiWidth;
flat in int kind;

uniform vec4 ColorModulator;

out vec4 fragColor;

const vec3 TOP = vec3(12.0, 22.0, 64.0) / 255.0;
const vec3 BOTTOM = vec3(84.0, 12.0, 28.0) / 255.0;
const vec4 RIM = vec4(1.0, 210.0 / 255.0, 90.0 / 255.0, 0.8);

void main() {
    vec4 color = vertexColor;
    // the rectangle this fragment belongs to, from how position and corner change across the screen
    mat2 dpos = mat2(dFdx(guiPos), dFdy(guiPos));
    mat2 duv = mat2(dFdx(corner), dFdy(corner));
    bool rect = abs(determinant(duv)) > 1e-9;
    vec2 mn = vec2(0.0);
    vec2 mx = vec2(0.0);
    if (rect) {
        mat2 D = dpos * inverse(duv);
        vec2 o = guiPos - D * corner;
        vec2 p1 = o + D[0];
        vec2 p2 = o + D[1];
        vec2 p3 = o + D[0] + D[1];
        mn = min(min(o, p1), min(p2, p3));
        mx = max(max(o, p1), max(p2, p3));
    }
    if (kind == 1) {
        if (rect) {
            float h = mx.y - mn.y;
            bool centred = abs(mn.x + mx.x - guiWidth) <= 2.5;
            int part = -1;
            if (centred && abs(mn.y - 9.0) < 0.5 && abs(h - 19.0) < 0.5) part = 0;        // header, 2 lines
            else if (centred && abs(mn.y - 28.0) < 0.5) part = 1;                          // players
            else if (centred && mn.y > 28.5 && abs(h - 19.0) < 0.5) part = 2;             // footer, 2 lines
            if (part >= 0) {
                float f = clamp((guiPos.y - mn.y) / max(h, 1.0), 0.0, 1.0);
                float k = part == 0 ? f * 0.12 : (part == 1 ? 0.12 + f * 0.76 : 0.88 + f * 0.12);
                color = vec4(mix(TOP, BOTTOM, k), 0.55);
                bool rim = guiPos.x - mn.x < 1.0 || mx.x - guiPos.x < 1.0
                        || (part == 0 && guiPos.y - mn.y < 1.0) || (part == 2 && mx.y - guiPos.y < 1.0);
                if (rim) color = RIM;
            }
        }
    } else if (kind == 2) {
        color = vec4(0.75, 0.88, 1.0, 0.1);
    } else if ((kind == 3 || kind == 4) && rect && abs(mx.x - (guiWidth - 1.0)) < 0.5) {
        // the sidebar (its right edge is 1 px from the screen's): the same gradient and frame as the tab,
        // the title band a little darker, a faint line under it
        float h = mx.y - mn.y;
        float f = clamp((guiPos.y - mn.y) / max(h, 1.0), 0.0, 1.0);
        bool title = kind == 3;
        color = vec4(mix(TOP, BOTTOM, title ? f * 0.08 : 0.08 + f * 0.92), title ? 0.68 : 0.55);
        if (!title && guiPos.y - mn.y < 1.0) color = vec4(1.0, 210.0 / 255.0, 90.0 / 255.0, 0.35);
        bool rim = guiPos.x - mn.x < 1.0 || mx.x - guiPos.x < 1.0
                || (title && guiPos.y - mn.y < 1.0) || (!title && mx.y - guiPos.y < 1.0);
        if (rim) color = RIM;
    }
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
