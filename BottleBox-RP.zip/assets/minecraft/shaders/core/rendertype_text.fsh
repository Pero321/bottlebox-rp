#version 150

#moj_import <minecraft:fog.glsl>

// BottleBox: vanilla text, except pixels with alpha 254 (the token bottle glyph) keep their own colours,
// scaled by how bright the text colour is (shadows stay dark).

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 texel = texture(Sampler0, texCoord0);
    vec4 color;
    if (abs(texel.a - 254.0 / 255.0) < 0.002) {
        float bright = max(vertexColor.r, max(vertexColor.g, vertexColor.b));
        color = vec4(texel.rgb * bright, vertexColor.a) * ColorModulator;
    } else {
        color = texel * vertexColor * ColorModulator;
    }
    if (color.a < 0.1) {
        discard;
    }
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
