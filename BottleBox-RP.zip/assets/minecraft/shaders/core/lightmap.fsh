#version 150

// BottleBox: fullbright - every block and sky light level is full brightness.

uniform float AmbientLightFactor;
uniform float SkyFactor;
uniform float BlockFactor;
uniform int UseBrightLightmap;
uniform vec3 SkyLightColor;
uniform float NightVisionFactor;
uniform float DarknessScale;
uniform float DarkenWorldFactor;
uniform float BrightnessFactor;

in vec2 texCoord;

out vec4 fragColor;

void main() {
    // keeps the uniforms alive without changing the result
    float keep = AmbientLightFactor + SkyFactor + BlockFactor + float(UseBrightLightmap) + SkyLightColor.r
            + NightVisionFactor + DarknessScale + DarkenWorldFactor + BrightnessFactor + texCoord.x;
    fragColor = vec4(1.0, 1.0, 1.0, 1.0) + vec4(min(keep, 0.0) * 0.0);
}
